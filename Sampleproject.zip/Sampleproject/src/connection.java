import java.sql.*;
public class connection {
	
	public static void main(String args[]) throws Exception
	{
		Class.forName("com.mysql.jdbc.Driver");  
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/studentinfo","admin","Admin@123");  
		System.out.println("connected");
	}

}
