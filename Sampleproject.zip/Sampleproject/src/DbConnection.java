import java.sql.*;

public class DbConnection {
	private Connection con = null;
    private Statement stmt = null;
    //private PreparedStatement preparedStatement = null;
    private ResultSet rs = null;
    
    public void dbupdate(String sname ,String fname,String mname,String dob, String emailid, String contactno,String gender,String course, String city) throws Exception
    {
    	try
    	{ 
    		//String sname ,String fname,String mname,String dob, String emailid, String contactno,String gender,String course, String city
    		
    		
    		Class.forName("com.mysql.jdbc.Driver");  
    		//Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/studentinfo","admin","Admin@123");  
    		Connection con=DriverManager.getConnection("jdbc:mysql://mysqldb.clarb7i6vgmg.us-east-1.rds.amazonaws.com:3306","muser","muser123"); 
    		System.out.println("connected");
    		//stmt = con.createStatement();
    		String query="INSERT INTO studentinfo.student(studentname, fathername, mothername, dob, emailid, contactno, gender, course, city)" + "VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)";
    		PreparedStatement pstmt=con.prepareStatement(query); 
    		pstmt.setString(1,sname);
    		pstmt.setString(2,fname);
    		pstmt.setString(3,mname);
    		pstmt.setString(4,dob);
    		pstmt.setString(5,emailid);
    		pstmt.setString(6,contactno);
    		pstmt.setString(7,gender);
    		pstmt.setString(8,course);
    		pstmt.setString(9,city);
    		pstmt.executeUpdate(); 
    		System.out.println("table updated successfully");
    		//rs= stmt.executeQuery("select * from studentinfo.student");
    		/*while(rs.next())
    		{
    			String sname= rs.getString(2);
    			System.out.println(sname);
    		}*/
    		
    	}
    	
    	
    	
    	catch(Exception e)
    	{ System.out.println(e);}  
    	
    }

   /* public static void main(String[] args) throws Exception {
    	DbConnection dao = new DbConnection();
        dao.dbupdate();
    }*/
}
