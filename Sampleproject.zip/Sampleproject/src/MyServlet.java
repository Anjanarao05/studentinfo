import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/MyServlet")

public class MyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private String sname ,fname, mname, dob, emailid, city,contactno,gender,course; 
	//private int ,i;
	
    
 protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		sname=request.getParameter("studentname");
		fname=request.getParameter("fathername");
		mname=request.getParameter("mothername");
		dob=request.getParameter("dob");
		emailid=request.getParameter("emailid");
		contactno=request.getParameter("mobileno");
		gender=request.getParameter("gender");
		course=request.getParameter("course");
		city=request.getParameter("city");
		//System.out.println("gender is"+gender);
		
		DbConnection dbc= new DbConnection();
		try
		{
			dbc.dbupdate(sname, fname, mname, dob, emailid, contactno,gender,course, city);
		}
		catch(Exception e)
    	{ System.out.println(e);}
		
	}





}
